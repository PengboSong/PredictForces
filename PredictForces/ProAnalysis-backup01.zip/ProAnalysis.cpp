#include "ProAnalysis.h"

ProAnalysis::ProAnalysis(std::string fpath)
{
	lres = read(fpath);
	lresh = read_h(fpath);
	coord = gen_coord(lres);
	contact_map = gen_contact(lres);
	contact_pairs = gen_pairs(contact_map);
	pairn = contact_pairs.size();
	hessian = gen_hessian(contact_pairs);
}

ProAnalysis::~ProAnalysis()
{
}

std::string ProAnalysis::sslice(size_t begin, size_t end, std::string in)
{
	std::string out = "";
	if (begin < in.length() && end < in.length())
	{
		if (end > begin)
			for (size_t i = begin; i < end; i++)
				out += in[i];
		else if (end < begin)
			for (size_t i = begin; i < end; i--)
				out += in[i];
	}
	return out;
}

int ProAnalysis::sslice_int(size_t begin, size_t end, std::string in)
{
	int value = 0;
	std::stringstream tmp;
	if (begin < in.length() && end < in.length())
	{
		if (end > begin)
			for (size_t i = begin; i < end; i++)
				tmp << in[i];
		else if (end < begin)
			for (size_t i = begin; i < end; i--)
				tmp << in[i];
	}
	tmp >> value;
	return value;
}

double ProAnalysis::sslice_d(size_t begin, size_t end, std::string in)
{
	double value = 0.0;
	std::stringstream tmp;
	if (begin < in.length() && end < in.length())
	{
		if (end > begin)
			for (size_t i = begin; i < end; i++)
				tmp << in[i];
		else if (end < begin)
			for (size_t i = begin; i < end; i--)
				tmp << in[i];
	}
	tmp >> value;
	return value;
}

std::map<std::string, ProAnalysis::ResInfo> ProAnalysis::read_h(std::string fpath)
{
	std::string line;
	std::ifstream pdb(fpath);
	std::map<std::string, ResInfo> resinfo;
	size_t id = 0;
	if (pdb.is_open())
	{
		while (std::getline(pdb, line))
			if (sslice(0, 4, line) == "ATOM" && sslice(13, 15, line) == "CA")
			{
				ResInfo info;
				std::string index;

				info.resname = sslice(17, 20, line);
				info.chain = line.at(21);
				info.resid = sslice_int(22, 26, line);
				info.x = sslice_d(30, 38, line);
				info.y = sslice_d(38, 46, line);
				info.z = sslice_d(46, 54, line);
				info.bfactor = sslice_d(60, 66, line);
				index = pack_index(info.chain, info.resid);
				resinfo[index] = info;
				id++;
			}
		pdb.close();
		resn = id;
	}
	else
	{
		std::cout << "[Error] Unbale to open file " << fpath << '.' << std::endl;
	}
	return resinfo;
}

std::map<size_t, ProAnalysis::ResInfo> ProAnalysis::read(std::string fpath)
{
	std::string line;
	std::ifstream pdb(fpath);
	std::map<size_t, ResInfo> resinfo;
	size_t id = 0;
	if (pdb.is_open())
	{
		while (std::getline(pdb, line))
			if (sslice(0, 4, line) == "ATOM" && sslice(13, 15, line) == "CA")
			{
				ResInfo info;

				info.resname = sslice(17, 20, line);
				info.chain = line.at(21);
				info.resid = sslice_int(22, 26, line);
				info.x = sslice_d(30, 38, line);
				info.y = sslice_d(38, 46, line);
				info.z = sslice_d(46, 54, line);
				info.xyz.x = info.x;
				info.xyz.y = info.y;
				info.xyz.z = info.z;
				info.bfactor = sslice_d(60, 66, line);
				resinfo[id++] = info;
			}
		pdb.close();
		resn = id;
	}
	else
	{
		std::cout << "[Error] Unbale to open file " << fpath << '.' << std::endl;
	}
	return resinfo;
}

Eigen::MatrixXi ProAnalysis::gen_contact(std::map<size_t, ResInfo> resinfo)
{
	Eigen::MatrixXi result = Eigen::MatrixXi::Zero(resn, resn);

	for (size_t i = 0; i < resn; i++)
	{
		result(i, i) = 1;
		for (size_t j = i + 1; j < resn; j++)
		{
			if (resinfo[i].chain == resinfo[j].chain && distance(i, j) < cutoff_intra)
			{
				result(i, j) = 2;
				result(j, i) = 2;
			}
			else if (resinfo[i].chain != resinfo[j].chain && distance(i, j) < cutoff_inter)
			{
				result(i, j) = 3;
				result(j, i) = 3;
			}
			else
			{
				result(i, j) = 0;
				result(j, i) = 0;
			}
		}
	}
	return result;
}

std::vector<ProAnalysis::pair> ProAnalysis::gen_pairs(Eigen::MatrixXi map)
{
	std::vector<pair> result;
	for (size_t i = 0; i < resn; i++)
		for (size_t j = i + 1; j < resn; j++)
			if (map(i, j) == 2 || map(i, j) == 3)
			{
				pair one{ i, j };
				result.push_back(one);
			}
	return result;
}

Eigen::VectorXd ProAnalysis::gen_coord(std::map<size_t, ResInfo> resinfo)
{
	Eigen::VectorXd vector = Eigen::VectorXd::Zero(3 * resn);
	for (size_t i = 0; i < resn; i++)
	{
		vector(3 * i) = resinfo[i].x;
		vector(3 * i + 1) = resinfo[i].y;
		vector(3 * i + 2) = resinfo[i].z;
	}
	return vector;
}

Eigen::MatrixXd ProAnalysis::gen_hessian(std::vector<pair> pairs)
{
	Eigen::MatrixXd matrix = Eigen::MatrixXd::Zero(3 * resn, 3 * resn);
	for (std::vector<pair>::iterator it = pairs.begin(); it != pairs.end(); it++)
	{
		double d = distance(*it);
		double k = k_default;
		if (get_contact(it->i, it->j) == 2)
			k = k_intra;
		else if (get_contact(it->i, it->j) == 3)
			k = k_inter;

		double hxx = -k * pow(diff_x(*it) / d, 2);
		double hyy = -k * pow(diff_y(*it) / d, 2);
		double hzz = -k * pow(diff_z(*it) / d, 2);
		double hxy = -k * diff_x(*it) * diff_y(*it) / pow(d, 2);
		double hxz = -k * diff_x(*it) * diff_z(*it) / pow(d, 2);
		double hyz = -k * diff_y(*it) * diff_z(*it) / pow(d, 2);

		matrix(3 * it->i, 3 * it->j) = hxx;
		matrix(3 * it->i, 3 * it->i) -= hxx;

		matrix(3 * it->i + 1, 3 * it->j + 1) = hyy;
		matrix(3 * it->i + 1, 3 * it->i + 1) -= hyy;

		matrix(3 * it->i + 2, 3 * it->j + 2) = hzz;
		matrix(3 * it->i + 2, 3 * it->i + 2) -= hzz;

		matrix(3 * it->i, 3 * it->j + 1) = hxy;
		matrix(3 * it->i, 3 * it->i + 1) -= hxy;
		matrix(3 * it->i + 1, 3 * it->j) = hxy;
		matrix(3 * it->i + 1, 3 * it->i) -= hxy;

		matrix(3 * it->i, 3 * it->j + 2) = hxz;
		matrix(3 * it->i, 3 * it->i + 2) -= hxz;
		matrix(3 * it->i + 2, 3 * it->j) = hxz;
		matrix(3 * it->i + 2, 3 * it->i) -= hxz;

		matrix(3 * it->i + 1, 3 * it->j + 2) = hyz;
		matrix(3 * it->i + 1, 3 * it->i + 2) -= hyz;
		matrix(3 * it->i + 2, 3 * it->j + 1) = hyz;
		matrix(3 * it->i + 2, 3 * it->i + 1) -= hyz;
	}
	return matrix;
}

std::string ProAnalysis::pack_index(std::string chain, size_t resid)
{
	std::stringstream tmp;
	std::string index;
	tmp << resid << chain;
	tmp >> index;
	return index;
}

double ProAnalysis::distance(size_t i, size_t j)
{
	return sqrt(pow(lres[i].x - lres[j].x, 2) + pow(lres[i].y - lres[j].y, 2) + pow(lres[i].z - lres[j].z, 2));
}

double ProAnalysis::diff_x(size_t i, size_t j)
{
	return lres[i].x - lres[j].x;
}

double ProAnalysis::diff_y(size_t i, size_t j)
{
	return lres[i].y - lres[j].y;
}

double ProAnalysis::diff_z(size_t i, size_t j)
{
	return lres[i].z - lres[j].z;
}

double ProAnalysis::distance(pair ij)
{
	return distance(ij.i, ij.j);
}

double ProAnalysis::diff_x(pair ij)
{
	return diff_x(ij.i, ij.j);
}

double ProAnalysis::diff_y(pair ij)
{
	return diff_y(ij.i, ij.j);
}

double ProAnalysis::diff_z(pair ij)
{
	return diff_z(ij.i, ij.j);
}

bool ProAnalysis::has_res(std::string res)
{
	bool flag = false;
	std::map<std::string, ResInfo>::iterator it;
	it = lresh.find(res);
	if (it != lresh.end())
		flag = true;
	return flag;
}

std::string ProAnalysis::get_resname(std::string res)
{
	if (has_res(res))
		return lresh[res].resname;
	else
		return std::string();
}

double ProAnalysis::get_x(std::string res)
{
	if (has_res(res))
		return lresh[res].x;
	else
		return 0.0;
}

double ProAnalysis::get_y(std::string res)
{
	if (has_res(res))
		return lresh[res].y;
	else
		return 0.0;
}

double ProAnalysis::get_z(std::string res)
{
	if (has_res(res))
		return lresh[res].z;
	else
		return 0.0;
}

double ProAnalysis::get_bfactor(std::string res)
{
	if (has_res(res))
		return lresh[res].bfactor;
	else
		return 0.0;
}

ProAnalysis::xyz ProAnalysis::get_xyz(std::string res)
{
	if (has_res(res))
		return xyz{ lresh[res].x, lresh[res].y, lresh[res].z };
	else
		return xyz{ 0.0, 0.0, 0.0 };
}

bool ProAnalysis::has_res(size_t id)
{
	if (id < resn)
		return true;
	else
		return false;
}

std::string ProAnalysis::get_resname(size_t id)
{
	if (id < resn)
		return lres[id].resname;
	else
		return std::string();
}

std::string ProAnalysis::get_chain(size_t id)
{
	if (id < resn)
		return lres[id].chain;
	else
		return std::string();
}

size_t ProAnalysis::get_resid(size_t id)
{
	if (id < resn)
		return lres[id].resid;
	else
		return 0;
}

double ProAnalysis::get_x(size_t id)
{
	if (id < resn)
		return lres[id].x;
	else
		return 0.0;
}

double ProAnalysis::get_y(size_t id)
{
	if (id < resn)
		return lres[id].y;
	else
		return 0.0;
}

double ProAnalysis::get_z(size_t id)
{
	if (id < resn)
		return lres[id].z;
	else
		return 0.0;
}

double ProAnalysis::get_bfactor(size_t id)
{
	if (id < resn)
		return lres[id].bfactor;
	else
		return 0.0;
}

ProAnalysis::xyz ProAnalysis::get_xyz(size_t id)
{
	if (id < resn)
		return lres[id].xyz;
	else
		return xyz{ 0.0, 0.0, 0.0 };
}

size_t ProAnalysis::get_resn()
{
	return resn;
}

int ProAnalysis::get_contact(size_t i, size_t j)
{
	if (i < resn && j < resn)
		return contact_map(i, j);
	else
		return 0;
}

Eigen::VectorXd ProAnalysis::get_coord()
{
	return coord;
}

Eigen::MatrixXd ProAnalysis::get_hessian()
{
	return hessian;
}

Eigen::Matrix3d ProAnalysis::get_hessian(size_t i, size_t j)
{
	if (i < resn && j < resn)
		return Eigen::Matrix3d(hessian.block(3 * i, 3 * j, 3, 3));
	else
		return Eigen::Matrix3d();
}

double ProAnalysis::get_hessian_s(size_t si, size_t sj)
{
	if (si < 3 * resn && sj < 3 * resn)
		return hessian(si, sj);
	else
		return 0.0;
}
