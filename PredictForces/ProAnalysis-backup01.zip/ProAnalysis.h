#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <map>

#include <Eigen/Dense>

class ProAnalysis
{
public:
	ProAnalysis(std::string fpath);
	~ProAnalysis();

	struct pair
	{
		size_t i;
		size_t j;
	};
	struct xyz
	{
		double x;
		double y;
		double z;
	};
	struct ResInfo
	{
		std::string resname;
		std::string chain;
		size_t resid;
		double x;
		double y;
		double z;
		xyz xyz;
		double bfactor;
	};

	bool has_res(std::string res);
	std::string get_resname(std::string res);
	double get_x(std::string res);
	double get_y(std::string res);
	double get_z(std::string res);
	double get_bfactor(std::string res);
	xyz get_xyz(std::string res);

	bool has_res(size_t id);
	std::string get_resname(size_t id);
	std::string get_chain(size_t id);
	size_t get_resid(size_t id);
	double get_x(size_t id);
	double get_y(size_t id);
	double get_z(size_t id);
	double get_bfactor(size_t id);
	xyz get_xyz(size_t id);

	size_t get_resn();
	int get_contact(size_t i, size_t j);

	Eigen::VectorXd get_coord();

	Eigen::MatrixXd get_hessian();
	Eigen::Matrix3d get_hessian(size_t i, size_t j);
	double get_hessian_s(size_t si, size_t sj);

private:
	std::string sslice(size_t begin, size_t end, std::string in);
	int sslice_int(size_t begin, size_t end, std::string in);
	double sslice_d(size_t begin, size_t end, std::string in);
	std::string pack_index(std::string chain, size_t resid);

	double distance(size_t i, size_t j);
	double diff_x(size_t i, size_t j);
	double diff_y(size_t i, size_t j);
	double diff_z(size_t i, size_t j);

	double distance(pair ij);
	double diff_x(pair ij);
	double diff_y(pair ij);
	double diff_z(pair ij);

	std::map<std::string, ResInfo> read_h(std::string fpath);
	std::map<size_t, ResInfo> read(std::string fpath);

	Eigen::MatrixXi gen_contact(std::map<size_t, ResInfo> resinfo);

	std::vector<pair> gen_pairs(Eigen::MatrixXi map);

	Eigen::VectorXd gen_coord(std::map<size_t, ResInfo> resinfo);

	Eigen::MatrixXd gen_hessian(std::vector<pair> pairs);
	
	std::map<std::string, ResInfo> lresh;
	std::map<size_t, ResInfo> lres;

	Eigen::MatrixXi contact_map;
	std::vector<pair> contact_pairs;
	Eigen::MatrixXd hessian;
	Eigen::VectorXd coord;

	size_t resn = 0;
	size_t pairn = 0;
	double cutoff_intra = 10.0;
	double cutoff_inter = 10.0;
	double k_intra = 1.0;
	double k_inter = 1.0;
	double k_default = 1.0;
};

